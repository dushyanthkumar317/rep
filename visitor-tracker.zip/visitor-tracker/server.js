const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/log-visitor", (req, res) => {
  const { isEmbedded, os, userAgent, location } = req.body;
  console.log("========== Visitor Info ==========");
  console.log("IP:", location.ip);
  console.log("Location:", `${location.city}, ${location.country}`);
  console.log("OS:", os);
  console.log("User Agent:", userAgent);
  console.log("Embedded:", isEmbedded);
  console.log("==================================");
  res.sendStatus(200);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});