const isEmbedded = window.self !== window.top;

function getOS(userAgent) {
  if (userAgent.includes("Win")) return "Windows";
  if (userAgent.includes("Mac")) return "macOS";
  if (userAgent.includes("Linux")) return "Linux";
  if (userAgent.includes("Android")) return "Android";
  if (userAgent.includes("like Mac")) return "iOS";
  return "Unknown";
}

const userAgent = navigator.userAgent;
const os = getOS(userAgent);
const token = "6312c66a8ffb78"; // Replace with your actual ipinfo token

fetch(`https://ipinfo.io/json?token=${token}`)
  .then(res => res.json())
  .then(data => {
    document.getElementById("info").innerHTML = `
      <strong>IP:</strong> ${data.ip}<br>
      <strong>City:</strong> ${data.city}<br>
      <strong>Country:</strong> ${data.country}<br>
      <strong>OS:</strong> ${os}<br>
    `;
    fetch("/log-visitor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        isEmbedded,
        os,
        userAgent,
        location: {
          ip: data.ip,
          city: data.city,
          region: data.region,
          country: data.country
        }
      })
    });
  })
  .catch(err => {
    console.error("Failed to fetch IP info:", err);
  });